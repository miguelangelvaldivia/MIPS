[![Contributors](https://img.shields.io/badge/contributors-6-red.svg)](https://uk-gitlab.almuk.santanderuk.corp/POC_Community/New_concepts/POC34_Bank_in_a_Box/graphs/master)
[![Tech](https://img.shields.io/badge/tech-blockchain-yellowgreen.svg)]()
[![Why](https://img.shields.io/badge/why-cost_saving-ff69b4.svg)]()
[![Sponsors](https://img.shields.io/badge/sponsor-DTP-blue.svg)]()
[![License](https://img.shields.io/badge/license-TBC-green.svg)]()


# Authors

Sri Yalamanchili,
Jorge Vallejo,
Miguel A. Valdivia, 
Francisco Jimenez,
Necati Tok,
Alberto Pulido

# Start Script

  - Start hyperledger fabric network
  - delete existing PeerAdmin card
  - create new PeerAdmin card
  - import PeerAdmin card

    ```sh
    $ cd app-hlfabric/network/scripts
    $ ./start-hlf-network.sh
    ```

# Stop Script

  - Stop hyperledger fabric network
  - delete the docker containers and dev- images of HL Fabric network

    ```sh
    $ cd app-hlfabric/network/scripts
    $ ./stop-hlf-network.sh
    ```