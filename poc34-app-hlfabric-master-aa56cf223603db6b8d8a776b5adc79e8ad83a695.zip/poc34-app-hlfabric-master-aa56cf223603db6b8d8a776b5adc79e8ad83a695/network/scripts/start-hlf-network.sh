#!/bin/bash

echo "starting fabric network"
./startFabric.sh

if [ "$?" -ne 0 ]; then
  echo "Failed to start Fabric network..."
  exit 1
fi

echo "Delete existing cards, if any"
composer card list
composer card delete -n PeerAdmin@poc34-bix-network
composer card delete -n admin@poc34-bix-app

echo "Create new card for PeerAdmin"
composer card create -p ./../connection.json -u PeerAdmin -c ./../fabric-scripts/hlfv1/composer/crypto-config/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp/signcerts/Admin@org1.example.com-cert.pem -k ./../fabric-scripts/hlfv1/composer/crypto-config/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp/keystore/114aab0e76bf0c78308f89efc4b8c9423e31568da0c340ca187a9b17aa9a4457_sk -r PeerAdmin -r ChannelAdmin

if [ "$?" -ne 0 ]; then
  echo "Failed to create PeerAdmin card..."
  exit 1
fi

echo "Import the card"
composer card import -f PeerAdmin@poc34-bix-network.card

if [ "$?" -ne 0 ]; then
  echo "Failed to import PeerAdmin@poc34-bix-network.card into fabric network..."
  exit 1
fi

echo "Started network successfully !!"
