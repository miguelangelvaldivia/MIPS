/**
 * POC34 - Smart contract to run the monthly settlement for 123 Accounts - triggering cashback payments, interest payment, and monthly fee
 * @param {com.santech.poc34.transactions.OneTwoThreeMonthlySettlement} settlement
 * @transaction
 */
function onOneTwoThreeMonthlySettlement(settlement) {
    var account = settlement.account;
    var dates = getDates(account);
    var factory = getFactory();

    settlement.settlementDate = dates.to;

    account = monthlyCharge(account, settlement.timestamp);

    if (validConditions(account, dates)) {
        account = processPayments(account, dates, factory);
    }

    if(settlement.simulate) { 
        var interest = account.movements.pop();
        var cbA = account.movements.pop();
        var cbB = account.movements.pop();
        var cbC = account.movements.pop();

        console.log("CashBack ", cbA.cashBackRate);
        console.log(cbA.value);
        console.log("CashBack ", cbB.cashBackRate);
        console.log(cbB.value);
        console.log("CashBack ", cbC.cashBackRate);
        console.log(cbC.value);
        console.log("Total CashBack")
        console.log(cbA.value + cbB.value + cbC.value)
        console.log("Interest");
        console.log(interest.value);

        return true;
    }

    return getAssetRegistry(oneTwoThreeAccountNS)
    .then(function(assetRegistry) {
        return assetRegistry.update(account);
    });
}

function monthlyCharge(account, date) {
    // TEMPORARY - this needs to be made an indpendent transaction
    account.balance.ammount -= 5.0;
    account.balance.asOfDate = date;

    return account;
}

function processPayments(account, dates, factory) {
    cashBackRates.forEach(function(rate) {
        account = buildCashBackPayment(account, dates, rate, factory);
    });

    account = buildInterestPayment(account, dates, factory);

    return account;
}

function getDates(account) {
    var dateTo = getOneTwoThreePaymentDate(account.openingDate, new Date());
    var previousDate = getOneTwoThreePaymentDate(account.openingDate, decrementDate(dateTo, 1));
    var dateFrom = incrementDate(previousDate, 1);

    return { from: dateFrom, to: dateTo };
}

function validConditions(account, dates) {
    // return noExistingSettlement(account, dates) && minimumInput(account, dates) && minimumDebits(account, dates);
    return true;
}

function noExistingSettlement(account, dates) {
    return true;
}

function minimumInput(account, dates) {
    return true;
}

function minimumDebits(account, dates) {
    return true;
}