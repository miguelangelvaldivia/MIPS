function buildInterestPayment(account, dates, factory) {
    var rate = account.product.interestRate
    var payment = factory.newResource(transactionsNS, interestPayment, 'lelele');

    payment = populateInterestPayment(payment, account, dates, rate);
    account = updateAccountInterestPayment(payment, account, dates);

    return account;
}

function populateInterestPayment(payment, account, dates, rate) {
    var accountMovements = account.movements
    var interestMovements = accountMovements.filter(isBetweenDates(dates))
    var initialBalance = getInitialBalance(accountMovements, dates.from);

    payment.value = +(calculateInterest(interestMovements, initialBalance, dates, rate, account.product.maximumDailyBalance).toFixed(2));
    payment.referenceText = "Interest payment"
    payment.interestRate = rate;
    payment.balanceAfterTransaction = account.balance.ammount + payment.value;
    payment.account = account;
    payment.timestamp = new Date();
    payment.date = payment.timestamp;
    payment.dateFrom = dates.from;
    payment.dateTo = dates.to;
    payment.type = "Debit";

    return payment;
}

function updateAccountInterestPayment(payment, account, paymentDate) {
    account.balance.ammount = +(payment.balanceAfterTransaction.toFixed(2));
    account.balance.asOfDate = payment.date;
    account.movements.push(payment);

    return account;
}

function getInitialBalance(accountMovements, initialDate) {
    var i = 0;
    initialTreshold = incrementDate(initialDate, 1);

    while(accountMovements[i].date < initialTreshold) {
        i++;
    }

    if(accountMovements[i-1]) {
        return accountMovements[i-1].balanceAfterTransaction;
    }

    return 0;
}

function calculateInterest(movements, initialBalance, dates, rate, maximumDailyBalance) {
    var dailyBalances = getDailyBalances(movements, initialBalance, dates, maximumDailyBalance);

    accumulatedBalance = dailyBalances.reduce(add, 0) || 0;
    interestValue = accumulatedBalance * rate * 1e-2 / 365;

    return interestValue;
}

function getDailyBalances(movements, initialBalance, dates, maximumDailyBalance) {
    var dailyBalance = initialBalance;
    if(dailyBalance > maximumDailyBalance) {
        dailyBalance = maximumDailyBalance;
    }
    var dailyBalancesArray = [dailyBalance];


    for(date = dates.from; date < dates.to; date = incrementDate(date, 1)) {
        dailyMovements = movements.filter(isSameDay(date));

        if(dailyMovements.length > 0) {
            dailyBalance = dailyMovements.slice(-1)[0].balanceAfterTransaction;
            if(dailyBalance > maximumDailyBalance) {
                dailyBalance = maximumDailyBalance;
            }
        }

        dailyBalancesArray.push(dailyBalance);
    }

    return dailyBalancesArray;
}
