function buildCashBackPayment(account, dates, rate, factory) {
    var cashBackMovements = filterCashBackMovements(account.movements, dates, rate);
    var payment = factory.newResource(transactionsNS, cashBackPayment, 'lalala');

    payment = populateCashBack(payment, account, cashBackMovements, rate, dates)
    account = updateAccountCashBackPayments(payment, account)

    return account;
}

function populateCashBack(payment, account, cashBackMovements, rate, dates) {
    payment.value = +(cashBackMovements.map(calculate).reduce(add, 0).toFixed(2)) || 0.00;
    payment.movementsPayed = addMovementIds(cashBackMovements);
    payment.referenceText = "Cashback payment for rate " + rate;
    payment.cashBackRate = rate;
    payment.balanceAfterTransaction = +((account.balance.ammount + payment.value).toFixed(2));
    payment.account = account
    payment.timestamp = new Date();
    payment.date = payment.timestamp;
    payment.dateFrom = dates.from;
    payment.dateTo = dates.to;
    payment.type = "Debit";

    return payment;
}

function updateAccountCashBackPayments(payment, account) {
    account.balance.ammount = payment.balanceAfterTransaction;
    account.balance.asOfDate = payment.date;
    account.movements.push(payment);

    return account;
}

function filterCashBackMovements(accountMovements, dates, rate) {
    var cashBackMovements = accountMovements.filter(isCashBackEligible).filter(isBetweenDates(dates)).filter(isCashBackRate(rate));
    return cashBackMovements;
}

function isCashBackRate(rate) {
    return function(movement) {
        return movement.cashBackRate === rate;
    }
}

function isCashBackEligible(movement) {
    return movement.getType() === 'DirectDebitPayment';
}

function calculate(movement) {
    var value = movement.value;

    if(movement.payee.maximumApplicableAmount > 0.0) {
        if(value > movement.payee.maximumApplicableAmount) {
            value = movement.payee.maximumApplicableAmount;
        }
    }

    var cashBack = value * movement.cashBackRate * 1e-2;

    return cashBack;
}

function addMovementIds(movements) {
    idsArray = [];

    movements.forEach( function(movement) {
        idsArray.push(movement.getIdentifier());
    });

    return idsArray;
}
