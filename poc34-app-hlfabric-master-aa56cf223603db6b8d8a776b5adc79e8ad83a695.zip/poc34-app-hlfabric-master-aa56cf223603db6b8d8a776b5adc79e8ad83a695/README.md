[![Contributors](https://img.shields.io/badge/contributors-2-red.svg)](https://uk-gitlab.almuk.santanderuk.corp/POC_Community/New_concepts/POC34_BiX/poc34-app-hlfabric/graphs/master)
[![Tech](https://img.shields.io/badge/tech-blockchain-yellowgreen.svg)]()
[![Why](https://img.shields.io/badge/why-cost_saving-ff69b4.svg)]()
[![Sponsors](https://img.shields.io/badge/sponsor-DTP-blue.svg)]()
[![License](https://img.shields.io/badge/license-TBC-green.svg)]()


# Authors

Sri Yalamanchili,
Alberto Pulido,
Tiago de Sousa,
Jorge Vallejo,
Santosh Balmuri,
Miguel A. Valdivia, 
Francisco Jimenez,


# Summary

Blockchain implementation of Bank in a Box(Bix) on Hyperledger Fabric network.

# Overview

It contain below sub-modules. Each sub-module has a Readme file.

  - network
  - composer-app

# How to

Perform below steps:
  
  - network
    - Create Hyperledger Fabric network 

  - composer-app
    - Build and Deploy the Composer Application
    - Start Composer-Rest Server
    - Preload Data by running `scripts\preloadData.sh`
    - Run Cashback calculations by running `scripts\runCashback.sh`

